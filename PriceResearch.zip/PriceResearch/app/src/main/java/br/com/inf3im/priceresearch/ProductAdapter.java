package br.com.inf3im.priceresearch;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import br.com.inf3dm.example.priceresearch.R;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder> implements Filterable {

    public static final String TAG = "Product Adapter";

    // definir escutadores/ouvintes de clique no ITEM de tela
    private View.OnClickListener mOnItemClickListener;
    private View.OnLongClickListener mOnItemLongClickListener;

    private Context mContext;

    // definir objetos de lista ( SELECT = List<Product> listAllProducts(Context mContext) )
    private List<Product> mProductList;
    // lista reserva para dar agilidade quando aplicar filtro
    private List<Product> mProductListFull;
    // o objeto mProductListFull permite que NAO SEJA FEITA um acesso ao Banco de Dados
    // operação com banco de dados custa 'caro'

    // objeto para exibir o total da compra
    private TextView mTextViewTotalPrice;

    //criar o construtor da classe ProductAdapter


    public ProductAdapter(Context context, List<Product> productList, TextView textViewTotalPrice) {
        mContext = context;
        mProductList = productList;
        mTextViewTotalPrice = textViewTotalPrice;
    }

    // funcionalidade para trocar a cor do preço que depende de uma avaliação
    // cor = f(rating)        y = f(x)
    // funcionalidade = funcao = metodo = acao
    // trocar a cor é uma regra de negocio - o codigo abaixo dever estar em outra classe
    // isso deve ser feito para manter o código limpo (técnica CLEAN CODE)
    public String setPriceColor(double vRating) {
        if( vRating < 3 ){
            return "#BF0404"; //vermelho
        } else {
            return "#000000"; //preto
        }

    }






    @Override
    public Filter getFilter() {
        return applyProductFilter;
    }

    @NonNull
    @Override
    public ProductAdapter.ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // responsavel por exibir o item na lista
        LayoutInflater mLayoutInflater = LayoutInflater.from(mContext);
        View mItemView = mLayoutInflater.inflate(R.layout.card_item_product_list , parent , false);

        return new ProductViewHolder(mItemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductAdapter.ProductViewHolder holder, int position) {
        Product mProductCurrent = mProductList.get(position);
        // definir o que será apresentado
        holder.mTextViewItemProductName.setText(mProductCurrent.getName());
        // current = atual
        holder.mTextViewItemProductPrice.setText(   "" +  mProductCurrent.getPrice());
        holder.mTextViewItemProductPrice.setTextColor(Color.parseColor(setPriceColor(mProductCurrent.getRating())));
        holder.mRatingBarItemProductStar.setRating(mProductCurrent.getRating());
        holder.mButtonProductQuantity.setText("" + mProductCurrent.getUnit()  );




    }

    @Override
    public int getItemCount() {
        // teste    IF
        if(mProductList != null){
            return mProductList.size();
        } else {

            return 0;
        }


    }


    // definir uma funcionalidade/acao/metodo para exibir a lista
    // quando cancelar uma busca
    public void setProductList(List<Product> mProductS  ){
        mProductList = mProductS;
        mProductListFull = new ArrayList<>(mProductS); //Array  lista dinamica
        notifyDataSetChanged();
    }


    public class ProductViewHolder extends RecyclerView.ViewHolder {
        // essa subclasse é responsavel por ativar os elementos
        // de tela com o codigo java
        // aqui teremos os elementos do CARDVIEW
        private final ImageView mImageViewProduct;
        private final TextView mTextViewItemProductName;
        private final TextView mTextViewItemProductPrice;
        private final RatingBar mRatingBarItemProductStar;
        private final Button mButtonProductAdd;
        private final Button mButtonProductRemove;
        private final Button mButtonProductQuantity;

        // variavéis para controlar quantidade e o preço total da compra
        int vQuantity = 0;
        double vTotalPrice = 0.0;

        //uma regra de negocio para totalizar o valor da compra
        //NAO DEVE SER FEITO AQUI - boa pratica de programacao CLEAN CODE
        private void showTotalPrice(){
            vTotalPrice = 0.0;
            // laço de repeticao     for
            for( int i=0 ; i <= mProductList.size()-1 ; i++ ){
                vTotalPrice = vTotalPrice + mProductList.get(i).getPrice() * mProductList.get(i).getUnit();
            }
            NumberFormat mNumberFormat = NumberFormat.getCurrencyInstance(new Locale("pt" , "BR"));
            String mStringValue = mNumberFormat.format(vTotalPrice);
            mTextViewTotalPrice.setText(mStringValue);




        }




        // classe interna para escutar/ouvir o clique no botao de adicionar produto
        public class ClickMyButtonAdd implements View.OnClickListener{
            @Override
            public void onClick(View v) {
                vQuantity = mProductList.get(getAdapterPosition()).getUnit() +1 ;
                mButtonProductQuantity.setText("" + vQuantity  );
                mProductList.get(getAdapterPosition()).setUnit(vQuantity);
            }
        }
        public class ClickMyButtonRemove implements View.OnClickListener{
            @Override
            public void onClick(View v) {
                vQuantity = mProductList.get(getAdapterPosition()).getUnit() -1 ;
                mButtonProductQuantity.setText("" + vQuantity  );
                mProductList.get(getAdapterPosition()).setUnit(vQuantity);
            }
        }



        public ProductViewHolder(@NonNull View itemView) {
            super(itemView);
            // associar os objetos java com os elementos do layout - o item que será clicado
            mTextViewItemProductName = itemView.findViewById(R.id.textView_item_product_name_rev2);
            mTextViewItemProductPrice = itemView.findViewById(R.id.textView_item_product_price_rev2);
            mImageViewProduct = itemView.findViewById(R.id.image_item_product_list_rev2);
            mRatingBarItemProductStar = itemView.findViewById(R.id.ratingBar_item_product_price_perception_rev2);
            mButtonProductAdd = itemView.findViewById(R.id.button_product_add_rev2);
            mButtonProductRemove = itemView.findViewById(R.id.button_product_remove_rev2);
            mButtonProductQuantity = itemView.findViewById(R.id.button_product_quantity_rev2);
            // configurando os escutadores/ouvintes de clique para os botoes
            mButtonProductAdd.setOnClickListener(new ClickMyButtonAdd());
            mButtonProductRemove.setOnClickListener(new ClickMyButtonRemove());
            // definir o clique no item da lista
            itemView.setOnClickListener(mOnItemClickListener);



        }
    }


    public void setOnClickListener(View.OnClickListener  mOnClickListener  ) {
        mOnItemClickListener = mOnClickListener;
    }


    public void setOnLongClickListener(View.OnLongClickListener mOnLongClickListener){
        mOnItemLongClickListener = mOnLongClickListener;
    }

    // Código para aplicar o filtro para encontrar PRODUTOS por parte do nome
    // buscar/localizar

    private Filter applyProductFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
           List<Product> mFilteredList = new ArrayList<>();  //Array = dinamica = que muda
            // testar se foi digitado a regra=constraint
            if(constraint == null){
                mFilteredList.addAll(mProductListFull);
            } else {
                //padrao para a digitacao
                String mPattern = constraint.toString().toLowerCase().trim();
                // testar o padrao com o nome do produto na lista
                // como é uma lista de produtos é necessário criar
                // a lista com os 'nomes' que atendem ao padrao
                // vou fazer uma repeticao para isso
                for( Product mProduct : mProductList ){
                    if(  mProduct.getName().toLowerCase().contains(mPattern)  ){
                        mFilteredList.add(mProduct);
                    }
                }

            }

           FilterResults mFilterResults = new FilterResults();
            mFilterResults.values = mFilteredList;
            return mFilterResults;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            mProductList.clear();
            mProductList.addAll( (List) results.values  );
            notifyDataSetChanged();

        }
    };



}
