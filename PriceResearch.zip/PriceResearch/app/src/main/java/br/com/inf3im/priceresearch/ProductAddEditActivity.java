package br.com.inf3im.priceresearch;

import android.content.Intent;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.slider.Slider;

public class ProductAddEditActivity extends AppCompatActivity {

    public static final String TAG = "Add Edit Class Product";

    String mMode;
    TextView mTextViewCancel;
    Button mButtonSaveProduct;
    EditText mEditTextName, mEditTextPrice;
    RatingBar mRatingBarPriceStar;
    Slider mSliderCycle;
    ChipGroup mChipGroupOption; //caixa azul
    Chip mChip0, mChip1, mChip2, mChip3, mChip4;
    // variaveis de controle
    int vChipValue, vSliderValue;

    String mMessage;

    // funcionalidade para cancelar
    private void executeCancel(){
        Intent mIntentResponse = new Intent();
        setResult(RESULT_CANCELED , mIntentResponse);
        finish();
    }

   // ouvinte do clique para cancelar
    public class ClickMyCancel implements View

           .OnClickListener{
       @Override
       public void onClick(View v) {
           executeCancel();
       }
   }

   // regra de negocio: obrigatorio - nome, preco e frequencia
    private boolean isInputInvalid(){
        if(  vChipValue == 0 || TextUtils.isEmpty(mEditTextName.getText())  || TextUtils.isEmpty(mEditTextPrice.getText()) ){
            return true;
        } else {
            return false;
        }


//        if(vChipValue == 0){
//            return  true;
//        } else {
//            return false;
//        }
//
//        if(TextUtils.isEmpty(mEditTextName.getText())){
//            return  true;
//        } else {
//            return false;
//        }
//
//        if(TextUtils.isEmpty(mEditTextPrice.getText())){
//            return  true;
//        } else {
//            return false;
//        }


    }

    // funcionalidade para retornar com os dados
    // para a atividade anterior INSERT/UPDATE  modo ADD/EDIT
    private void saveProduct(){
        if(isInputInvalid()){
            mMessage="Nome, preco e frequencia verifique - sao obrigatorios";
            Toast.makeText(getApplicationContext() , mMessage , Toast.LENGTH_SHORT).show();
            return;
        }

        Intent mIntentResponse = new Intent();
        mMode="ADD"; // assumo que estou sempre INSERT
        int vId = getIntent().getIntExtra("EXTRA_ID" , -1 );
        if(vId != -1){
            mMode="EDIT";
            mIntentResponse.putExtra("EXTRA_ID"  , vId  );
        }
        String mName = mEditTextName.getText().toString();
        mIntentResponse.putExtra("EXTRA_NAME"  ,  mName);

        float vPrice = Float.valueOf(mEditTextPrice.getText().toString());
        mIntentResponse.putExtra("EXTRA_PRICE"  , vPrice );

        float vPerception = mRatingBarPriceStar.getRating();
        mIntentResponse.putExtra("EXTRA_PERCEPTION" , vPerception);
        mIntentResponse.putExtra("EXTRA_AMOUNT" , vSliderValue);
        mIntentResponse.putExtra("EXTRA_FREQUENCY" , vChipValue);
        mIntentResponse.putExtra("EXTRA_MODE" , mMode);

        setResult(RESULT_OK , mIntentResponse);
        finish();

    }


            public class ClickMyButtonSave implements View.OnClickListener{

    @Override
    public void onClick(View v) {
       saveProduct();
    }
    }
    public class SliderMySlide implements  View.OnClickListener{
        @Override
        public void onValueChange(@NonNull Slider slider, float value, boolean fromUser )
            vSliderValue = (int) value;
    }
}

